import React, { useState, useEffect } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'motion/react';
import { 
  Wallet, 
  Coins, 
  Eye, 
  Newspaper, 
  ShoppingBag, 
  TrendingUp, 
  PlusCircle, 
  Sparkles, 
  CheckCircle2, 
  HelpCircle,
  Clock,
  Compass,
  DollarSign,
  UserCheck,
  Globe,
  Share2,
  ListFilter,
  CheckCircle,
  Activity,
  History,
  Plus,
  Moon,
  Sun,
  AlertCircle,
  Lock,
  Mail,
  User,
  UserPlus,
  ShieldAlert,
  LogOut,
  RefreshCw,
  Shield,
  Award,
  Trash2
} from 'lucide-react';
import { INITIAL_CAMPAIGNS } from './data/campaigns';
import { WebsiteCampaign, WithdrawalRequest, ActivityLog, UserStats, ReferralFriend, Subscription } from './types';
import BrowserSimulator from './components/BrowserSimulator';
import GCashCashout from './components/GCashCashout';
import ReferralPanel from './components/ReferralPanel';
import AdminPanel from './components/AdminPanel';
import { soundEffects } from './utils/audio';

interface UserSession {
  id: string;
  email: string;
  name: string;
  avatar: string;
  isAdmin: boolean;
  referralCode: string;
  stats: UserStats;
  withdrawals: WithdrawalRequest[];
  activityLogs: ActivityLog[];
  referredFriends: ReferralFriend[];
  createdAt?: string;
  subscription?: Subscription;
}

export default function App() {
  // --- AUTHENTICATION & SYNC STATES ---
  const [token, setToken] = useState<string | null>(localStorage.getItem('gcash_click_earn_token'));
  const [user, setUser] = useState<UserSession | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(false);

  // Form states
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [referralInput, setReferralInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [showGoogleChooser, setShowGoogleChooser] = useState(false);

  // --- CORE APP STATES ---
  const [stats, setStats] = useState<UserStats>({
    balance: 25.00,
    lifetimeEarnings: 25.00,
    completedTasksCount: 0,
    dailyCheckInDate: null
  });

  const [campaigns, setCampaigns] = useState<WebsiteCampaign[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [referredFriends, setReferredFriends] = useState<ReferralFriend[]>([]);
  
  const [activeTab, setActiveTab] = useState<'earn' | 'cashout' | 'guide' | 'admin'>('earn');
  const [currentViewingCampaign, setCurrentViewingCampaign] = useState<WebsiteCampaign | null>(null);

  // Add custom campaigns state
  const [customTitle, setCustomTitle] = useState('');
  const [customUrl, setCustomUrl] = useState('');
  const [customReward, setCustomReward] = useState('0.75');
  const [customTimer, setCustomTimer] = useState('15');
  const [customDescription, setCustomDescription] = useState('');
  const [campaignFilter, setCampaignFilter] = useState<'all' | 'high' | 'available'>('all');

  // Animation states
  const [floatingCoinReward, setFloatingCoinReward] = useState<number | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  
  // Language switcher state (English default)
  const [language, setLanguage] = useState<'en' | 'tl'>((localStorage.getItem('user_lang') as 'en' | 'tl') || 'en');

  useEffect(() => {
    localStorage.setItem('user_lang', language);
  }, [language]);

  // Dynamically backup active user profile and stats locally to recover transparently after server cold starts/reboots
  useEffect(() => {
    if (user) {
      let savedPassword = '';
      const existingBackupStr = localStorage.getItem('gcash_user_backup_profile');
      if (existingBackupStr) {
        try {
          const parsed = JSON.parse(existingBackupStr);
          if (parsed && parsed.password) {
            savedPassword = parsed.password;
          }
        } catch (_) {}
      }

      if (!savedPassword && passwordInput) {
        savedPassword = passwordInput;
      }

      localStorage.setItem('gcash_user_backup_profile', JSON.stringify({
        ...user,
        password: savedPassword || (user as any).password
      }));
    }
  }, [user, passwordInput]);

  // --- NOTIFICATION BANNER STATE ---
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);
  
  const triggerNotification = (message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification((curr) => curr?.message === message ? null : curr);
    }, 4500);
  };

  // --- COMPILATION & SETUP EFFECTS ---

  // Check for auto referral code in URL parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setReferralInput(ref);
      setAuthMode('register');
      triggerNotification(`🔗 Referral Link na-detect! Awtomatikong sinali sa ref code: ${ref}`, 'info');
    }
  }, []);

  // Fetch or sync user profile
  const fetchUserProfile = async (authToken: string) => {
    setLoadingProfile(true);
    try {
      const res = await fetch('/api/user/profile', {
        headers: {
          'Authorization': authToken
        }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setStats(data.user.stats);
        setWithdrawals(data.user.withdrawals);
        setActivityLogs(data.user.activityLogs);
        setReferredFriends(data.user.referredFriends);
        
        // Load campaigns directly from our centralized cloud backend
        try {
          const campRes = await fetch('/api/campaigns', {
            headers: {
              'Authorization': authToken
            }
          });
          if (campRes.ok) {
            const campData = await campRes.json();
            setCampaigns(campData.campaigns);
          } else {
            throw new Error('Failed to fetch from /api/campaigns');
          }
        } catch (cErr) {
          console.error('Error fetching campaigns from backend, using fallback:', cErr);
          const mapped = INITIAL_CAMPAIGNS.map(c => ({
            ...c,
            completed: data.user.activityLogs.some((l: any) => l.type === 'reward' && l.title.includes(c.title))
          }));
          setCampaigns(mapped);
        }

        // Auto transition into admin panel tab if they are logged in as admin to save steps
        if (data.user.isAdmin && activeTab === 'earn') {
          setActiveTab('admin');
        }
      } else {
        // Token has expired/invalid, or server rebooted on Cloud Run. Try auto-restoring session from offline backup!
        const backupStr = localStorage.getItem('gcash_user_backup_profile');
        if (backupStr) {
          try {
            const backupProfile = JSON.parse(backupStr);
            if (backupProfile && backupProfile.email && backupProfile.password && backupProfile.name) {
              const restoreRes = await fetch('/api/auth/auto-restore', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                  email: backupProfile.email,
                  password: backupProfile.password,
                  name: backupProfile.name,
                  avatar: backupProfile.avatar,
                  stats: backupProfile.stats,
                  withdrawals: backupProfile.withdrawals,
                  activityLogs: backupProfile.activityLogs,
                  referredFriends: backupProfile.referredFriends
                })
              });
              if (restoreRes.ok) {
                const restoreData = await restoreRes.json();
                localStorage.setItem('gcash_click_earn_token', restoreData.token);
                setToken(restoreData.token);
                setUser(restoreData.user);
                setStats(restoreData.user.stats);
                setWithdrawals(restoreData.user.withdrawals);
                setActivityLogs(restoreData.user.activityLogs);
                setReferredFriends(restoreData.user.referredFriends);
                triggerNotification('🔄 Ang iyong session at naipong balance ay ligtas na na-sync muli!', 'success');
                setLoadingProfile(false);
                return;
              }
            }
          } catch (restoreErr) {
            console.error('Failed to auto-restore session from backup:', restoreErr);
          }
        }

        // Token has expired or is invalid
        handleLogout();
      }
    } catch (e) {
      console.error(e);
      triggerNotification('⚠️ Connection error sa pag-load ng inyong Profile.', 'error');
    } finally {
      setLoadingProfile(false);
    }
  };

  // Trigger sync on login status change
  useEffect(() => {
    if (token) {
      fetchUserProfile(token);
    } else {
      setUser(null);
    }
  }, [token]);

  // Periodic active polling check to sync admin or other devices' actions
  useEffect(() => {
    if (!token) return;
    const interval = setInterval(() => {
      fetchUserProfile(token);
    }, 10000); // Poll every 10 seconds to align with admin approvals/declines instantly
    return () => clearInterval(interval);
  }, [token, activeTab]);

  // --- SUBSCRIPTIONS STATE & CALCULATIONS ---
  const [submittingSubscription, setSubmittingSubscription] = useState(false);

  const isSubscriptionExpired = () => {
    if (!user) return false;
    if (user.isAdmin) return false;
    
    // Check registration creation date
    const regDate = user.createdAt ? new Date(user.createdAt) : new Date();
    const passedMs = Date.now() - regDate.getTime();
    const oneDayInMs = 24 * 60 * 60 * 1000;
    
    // Free trial active if registered less than 24 hours ago
    if (passedMs < oneDayInMs) {
      return false; 
    }
    
    // Check active subscription status
    const sub = user.subscription;
    if (!sub || sub.status !== 'active') {
      return true; // Locked out
    }
    
    if (sub.expiresAt) {
      return new Date(sub.expiresAt).getTime() < Date.now();
    }
    
    return true; // Locked
  };

  // --- ACCESS STATUS HELPER ---
  const getAccessDetails = () => {
    const isTl = language === 'tl';
    if (!user) {
      return { 
        status: 'none', 
        label: isTl ? 'Walang Account' : 'No Account', 
        color: 'text-slate-400 bg-slate-800/50 border border-slate-700/50', 
        expiresText: '', 
        icon: AlertCircle 
      };
    }
    if (user.isAdmin) {
      return { 
        status: 'admin', 
        label: isTl ? 'Akses Admin' : 'Admin Access', 
        color: 'text-rose-400 bg-rose-500/10 border border-rose-500/25', 
        expiresText: isTl ? 'Lifetime Akses (Admin)' : 'Lifetime Access (Admin)', 
        icon: Shield 
      };
    }

    const regDate = user.createdAt ? new Date(user.createdAt) : new Date();
    const passedMs = Date.now() - regDate.getTime();
    const oneDayInMs = 24 * 60 * 60 * 1000;
    const remainingTrialMs = oneDayInMs - passedMs;

    const sub = user.subscription;

    // Check if subscription is active
    if (sub && sub.status === 'active' && sub.expiresAt) {
      const expiresDate = new Date(sub.expiresAt);
      const isExpired = expiresDate.getTime() < Date.now();
      
      if (!isExpired) {
        // Active subscription plan name translation
        let planLabel = isTl ? 'Premium Akses' : 'Premium Access';
        if (sub.planId === '1month') planLabel = isTl ? '1-Buwang Premium' : '1-Month Premium';
        else if (sub.planId === '2months') planLabel = isTl ? '2-Buwang Premium' : '2-Months Premium';
        else if (sub.planId === '3months') planLabel = isTl ? '3-Buwang Premium' : '3-Months Premium';
        else if (sub.planId === '4months') planLabel = isTl ? '4-Buwang Premium' : '4-Months Premium';
        
        // Calculate remaining time
        const remainingMs = expiresDate.getTime() - Date.now();
        const remainingDays = Math.ceil(remainingMs / (24 * 60 * 60 * 1000));
        
        return {
          status: 'premium',
          label: planLabel,
          color: 'text-amber-400 bg-amber-500/10 border border-amber-500/20 shadow-sm shadow-amber-500/5',
          expiresText: isTl 
            ? `Matatapos sa: ${expiresDate.toLocaleDateString('fil-PH', { month: 'short', day: 'numeric', year: 'numeric' })} (${remainingDays} na araw natitira)`
            : `Expires on: ${expiresDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} (${remainingDays} days left)`,
          rawExpiry: expiresDate,
          remainingMs,
          icon: Sparkles
        };
      }
    }

    // Check if free trial is active
    if (remainingTrialMs > 0) {
      const hours = Math.floor(remainingTrialMs / (1000 * 60 * 60));
      const minutes = Math.floor((remainingTrialMs % (1000 * 60 * 60)) / (1000 * 60));
      const expiresDate = new Date(regDate.getTime() + oneDayInMs);
      
      return {
        status: 'trial',
        label: isTl ? 'Libreng 1-Day Trial' : 'Free 1-Day Trial',
        color: 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20',
        expiresText: isTl 
          ? `Mawawalan ng akses sa loob ng: ${hours}o ${minutes}m`
          : `Expires in: ${hours}h ${minutes}m`,
        rawExpiry: expiresDate,
        remainingMs: remainingTrialMs,
        icon: Clock
      };
    }

    // Otherwise, access is expired
    let expiredLabel = isTl ? 'Akses ay Expired' : 'Expired Access';
    if (sub && sub.status === 'pending') {
      expiredLabel = isTl ? 'Sinusuri Pa' : 'Pending Review';
      return {
        status: 'pending',
        label: expiredLabel,
        color: 'text-amber-500 bg-amber-500/10 border border-amber-500/20',
        expiresText: isTl ? 'Naghihintay ng Pag-approve ng Admin' : 'Awaiting Admin Approval',
        icon: Clock
      };
    }

    return {
      status: 'expired',
      label: expiredLabel,
      color: 'text-rose-400 bg-rose-500/10 border border-rose-500/20',
      expiresText: isTl ? 'Tapos na ang iyong libreng trial o subscription' : 'Your trial or subscription has expired',
      icon: Lock
    };
  };

  const handleSubscriptionRequest = async (planId: string) => {
    if (!token) return;
    setSubmittingSubscription(true);
    try {
      const res = await fetch('/api/subscription/request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token
        },
        body: JSON.stringify({ planId })
      });
      const result = await res.json();
      if (res.ok) {
        setUser(result.user);
        triggerNotification('📨 Ang iyong Subscription request ay natanggap ng Admin! Mangyaring magdeposito sa GCash.', 'success');
      } else {
        triggerNotification(`⚠️ ${result.error || 'Hindi maipadala ang request.'}`, 'error');
      }
    } catch (e) {
      console.error(e);
      triggerNotification('⚠️ Error sa pagkonekta sa server.', 'error');
    } finally {
      setSubmittingSubscription(false);
    }
  };

  const handleSimulateTrialExpiration = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/simulate-expire', {
        method: 'POST',
        headers: {
          'Authorization': token
        }
      });
      const result = await res.json();
      if (res.ok) {
        setUser(result.user);
        triggerNotification('⚡ Kunwari ay natapos na ang iyong 1-Day Trial! Subukan muli ang dashboard.', 'info');
      } else {
        triggerNotification(`⚠️ ${result.error || 'Hindi ma-expire ang trial.'}`, 'error');
      }
    } catch (e) {
      console.error(e);
      triggerNotification('⚠️ Error connecting to server.', 'error');
    }
  };

  // --- CORE SYSTEM CONTROLLER ACTIONS ---

  // 1. Daily Bonus Check-In Hook
  const handleDailyCheckIn = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/user/daily-checkin', {
        method: 'POST',
        headers: {
          'Authorization': token
        }
      });
      const result = await res.json();
      if (res.ok) {
        setUser(result.user);
        setStats(result.user.stats);
        setActivityLogs(result.user.activityLogs);
        
        // Play sound effect
        soundEffects.playReward();
        
        // Show visual coin rewards
        setFloatingCoinReward(5.00);
        setShowConfetti(true);
        triggerNotification('💰 +₱5.00 Instant GCash Bonus idinagdag sa iyong Wallet!', 'success');
        setTimeout(() => {
          setFloatingCoinReward(null);
          setShowConfetti(false);
        }, 4000);
      } else {
        triggerNotification(`⚠️ ${result.error || 'Hindi ma-claim ang bonus.'}`, 'error');
      }
    } catch (e) {
      console.error(e);
      triggerNotification('⚠️ Error connecting to server.', 'error');
    }
  };

  // 2. Open Website homepage for earning
  const handleOpenCampaign = (campaign: WebsiteCampaign) => {
    setCurrentViewingCampaign(campaign);
  };

  // 3. Complete browser simulator task
  const handleCompleteCampaignView = async (id: string, reward: number) => {
    if (!token) return;

    const matchCampaign = campaigns.find(c => c.id === id);
    const label = matchCampaign ? matchCampaign.title : 'Web Homepage View';

    try {
      const res = await fetch('/api/user/task-complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token
        },
        body: JSON.stringify({
          campaignId: id,
          rewardAmount: reward,
          title: `Natapos panoorin ang ${label}`,
          details: `Salamat sa pag-open at pananatili sa homepage ng ${label} nang ${matchCampaign?.timer || 10} segundo.`
        })
      });

      const result = await res.json();
      if (res.ok) {
        setUser(result.user);
        setStats(result.user.stats);
        setActivityLogs(result.user.activityLogs);
        
        // Mark campaign as completed locally
        const updatedCampaigns = campaigns.map((c) => {
          if (c.id === id) {
            return { ...c, completed: true };
          }
          return c;
        });
        setCampaigns(updatedCampaigns);
        localStorage.setItem('gcash_click_earn_campaigns', JSON.stringify(updatedCampaigns));

        // Play sound effect
        soundEffects.playReward();

        // Animate Coin Floating
        setFloatingCoinReward(reward);
        setShowConfetti(true);
        setCurrentViewingCampaign(null);
        triggerNotification(`💰 Matagumpay! Naka-ipon ka ng +₱${reward.toFixed(2)}`, 'success');

        setTimeout(() => {
          setFloatingCoinReward(null);
          setShowConfetti(false);
        }, 4000);
      } else {
        triggerNotification(`⚠️ ${result.error || 'Hindi mate-record ang task.'}`, 'error');
      }
    } catch (e) {
      console.error(e);
      triggerNotification('⚠️ Connection error recording completions.', 'error');
    }
  };

  // 4. Submit GCash Withdrawal
  const handleWithdrawalRequest = async (accountName: string, gcashNumber: string, amount: number) => {
    if (!token) return { success: false, message: 'Naka-logout ka.' };

    try {
      const res = await fetch('/api/user/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token
        },
        body: JSON.stringify({ accountName, gcashNumber, amount })
      });
      const result = await res.json();
      if (res.ok) {
        setUser(result.user);
        setStats(result.user.stats);
        setWithdrawals(result.user.withdrawals);
        setActivityLogs(result.user.activityLogs);
        
        // Play cha-ching sound
        soundEffects.playWithdraw();
        
        triggerNotification(`💸 Sumite ng Cashout (Binubuo)`, 'success');
        return { 
          success: true, 
          message: language === 'tl'
            ? `Ang transaksyon ay ipapadala sa iyong GCash number ${gcashNumber}. Ang iyong request ay naghihintay ng System Administrator Approval.`
            : `The transaction will be sent to your GCash number ${gcashNumber}. Your request is pending System Administrator Approval.`
        };
      } else {
        return { success: false, message: result.error || 'Hindi maiproseso.' };
      }
    } catch (e) {
      console.error(e);
      return { success: false, message: 'Server connection error.' };
    }
  };

  // 5. Add Custom Website Campaign
  const handleCreateCustomCampaign = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!customTitle.trim()) {
      triggerNotification('⚠️ Pakilagay ang pamagat (Website Title).', 'error');
      return;
    }

    if (!customUrl.trim()) {
      triggerNotification('⚠️ Pakilagay ang URL ng website.', 'error');
      return;
    }

    let finalUrl = customUrl.trim();
    if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
      finalUrl = 'https://' + finalUrl;
    }

    const rewardNum = parseFloat(customReward);
    const timerNum = parseInt(customTimer);

    const newCampaign: WebsiteCampaign = {
      id: 'custom-' + Date.now(),
      title: customTitle.trim(),
      url: finalUrl,
      reward: isNaN(rewardNum) ? 0.75 : rewardNum,
      timer: isNaN(timerNum) ? 15 : timerNum,
      completed: false,
      logo: 'Globe',
      category: 'E-Services',
      description: customDescription.trim() || 'Isang verified advertiser page para mas palawakin ang iyong simulated earnings.',
      mockPageContent: {
        heroTitle: customTitle.trim(),
        heroSubtitle: 'Maligayang pagdating sa aming isinadyang simulated ad landing partner. Manatili rito para sa automated GCash rewards!',
        primaryColor: '#1E40AF',
        accentColor: '#10B950',
        paragraphs: [
          'Salamat sa pagsuporta at pagbisita sa aming page upang matulungan kaming mai-optimize ang search visibility index.',
          'Ang simulated traffic flow na ito ay ligtas at direktang naka-link sa iyong aktibong user profile account.'
        ],
        features: [
          'SEO Rank Optimization',
          'Automated Traffic Validation',
          'Fast Rewards Payout Credits'
        ]
      }
    };

    try {
      const res = await fetch('/api/admin/campaigns', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token || ''
        },
        body: JSON.stringify({ campaign: newCampaign })
      });
      if (res.ok) {
        const result = await res.json();
        setCampaigns(result.campaigns);
        setCustomTitle('');
        setCustomUrl('');
        setCustomReward('0.75');
        setCustomTimer('15');
        setCustomDescription('');
        triggerNotification(`💡 Tagumpay na naidagdag ang "${newCampaign.title}"! Puwede na itong buksan at panoorin para may mapanalunang ₱${newCampaign.reward.toFixed(2)}.`, 'success');
      } else {
        const errData = await res.json();
        triggerNotification(`⚠️ Bigo sa pagpasa: ${errData.error || 'Server error'}`, 'error');
      }
    } catch (err) {
      console.error(err);
      triggerNotification('⚠️ Connection error sa server.', 'error');
    }
  };

  const handleDeleteCampaign = async (campaignId: string, campaignTitle: string) => {
    try {
      const res = await fetch(`/api/admin/campaigns/${campaignId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': token || ''
        }
      });
      if (res.ok) {
        const result = await res.json();
        setCampaigns(result.campaigns);
        triggerNotification(`🗑️ Tagumpay na tinanggal ang campaign: "${campaignTitle}"`, 'success');
      } else {
        const errData = await res.json();
        triggerNotification(`⚠️ Bigo sa pagtanggal: ${errData.error || 'Server error'}`, 'error');
      }
    } catch (err) {
      console.error(err);
      triggerNotification('⚠️ Connection error sa server.', 'error');
    }
  };

  // --- AUTHENTICATION INTERFACE HANDLERS ---
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthLoading(true);

    const endpoint = authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
    const payload = authMode === 'login' 
      ? { email: emailInput.trim(), password: passwordInput }
      : { name: nameInput.trim(), email: emailInput.trim(), password: passwordInput, referralCode: referralInput.trim() };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
      const result = await res.json();
      if (res.ok) {
        localStorage.setItem('gcash_click_earn_token', result.token);
        setToken(result.token);
        triggerNotification(authMode === 'login' ? '🔑 Welcome back!' : '🎉 Welcome! Tagumpay na ginawa ang account mo.', 'success');
      } else {
        setAuthError(result.error || 'May error sa authentication.');
      }
    } catch (err) {
      console.error(err);
      setAuthError('Hindi makakonekta sa central server.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSimulatedGoogleLogin = async (selectedName: string, selectedEmail: string, avatar: string) => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: selectedName,
          email: selectedEmail,
          avatar: avatar
        })
      });
      const result = await res.json();
      if (res.ok) {
        localStorage.setItem('gcash_click_earn_token', result.token);
        setToken(result.token);
        setShowGoogleChooser(false);
        triggerNotification(`🌐 Nag-sign in gamit ang Google: Hello, ${selectedName}!`, 'success');
      } else {
        setAuthError(result.error);
      }
    } catch (e) {
      setAuthError('Connection error resolving Google session.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('gcash_click_earn_token');
    setToken(null);
    setUser(null);
    setActiveTab('earn');
    triggerNotification('🔒 Ligtas kang naka-logout sa controller.', 'info');
  };

  // --- FILTERS LOGIC ---
  const filteredCampaigns = campaigns.filter((c) => {
    if (campaignFilter === 'high') return c.reward >= 1.00;
    if (campaignFilter === 'available') return !c.completed;
    return true;
  });

  return (
    <div id="application-sandbox-root" className="min-h-screen bg-slate-100 flex flex-col text-slate-800 font-sans antialiased selection:bg-blue-600 selection:text-white">
      
      {/* 🔔 FLOATING NOTIFICATION SYSTEM */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            id="system-banner"
            className={`fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-md w-[90%] p-4 rounded-2xl shadow-xl border flex items-start gap-3 backdrop-blur-md ${
              notification.type === 'success'
                ? 'bg-emerald-50/95 border-emerald-200 text-emerald-950'
                : notification.type === 'error'
                ? 'bg-rose-50/95 border-rose-200 text-rose-950'
                : 'bg-indigo-50/95 border-indigo-200 text-indigo-950'
            }`}
          >
            <div className={`p-1.5 rounded-xl shrink-0 ${
              notification.type === 'success' ? 'bg-emerald-100' : notification.type === 'error' ? 'bg-rose-100' : 'bg-indigo-100'
            }`}>
              {notification.type === 'success' ? '💰' : notification.type === 'error' ? '🚨' : 'ℹ️'}
            </div>
            <div className="flex-1">
              <span className="text-xs font-extrabold block text-slate-400 uppercase tracking-widest leading-none mb-1">GCash Rewards Alert</span>
              <p className="text-xs font-bold leading-normal">{notification.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 🪙 FLOATING COINS OVERLAYS ANIMATION */}
      <AnimatePresence>
        {floatingCoinReward !== null && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 100 }}
            animate={{ opacity: [1, 1, 0], scale: [1, 1.3, 1], y: -100 }}
            transition={{ duration: 1.5 }}
            className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center"
          >
            <div className="bg-gradient-to-br from-yellow-300 to-amber-500 text-slate-950 p-6 rounded-full shadow-2xl flex flex-col items-center justify-center border-4 border-yellow-200 aspect-square min-w-[120px]">
              <Coins className="w-10 h-10 animate-repeat animate-bounce" />
              <div className="text-xl font-black mt-1 font-mono">+₱{floatingCoinReward.toFixed(2)}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 🚀 SCREEN GATEWAY 1: NOT AUTHENTICATED SCREEN */}
      {!token || !user ? (
        <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 py-12 relative overflow-hidden">
          
          {/* Ambient Cosmic Neon background lights */}
          <div className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full bg-blue-600/10 blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-indigo-600/10 blur-3xl" />

          <div className="max-w-md w-full space-y-6 z-10">
            
            {/* LOGO TITLE */}
            <div className="text-center space-y-2">
              <span className="mx-auto bg-blue-600 text-white text-[10px] font-black tracking-widest uppercase px-3 py-1 rounded-full flex items-center gap-1 w-max">
                <Coins className="w-3.5 h-3.5 text-yellow-300 animate-bounce" />
                <span>ACTIVE EARNING PORTAL</span>
              </span>
              <h1 className="text-3xl font-black text-white tracking-tight leading-none">
                G-Click & Earn Homepage
              </h1>
              <p className="text-xs text-slate-400 max-w-sm mx-auto font-semibold">
                Simulan ang pagbisita sa mga verified web homepage upang makakuha ng automated GCash cashout rewards!
              </p>
            </div>

            {/* MAIN CREDENTIAL CARD */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 relative">
              
              {/* Form Tab Toggles */}
              <div className="flex border-b border-slate-850 gap-2 text-xs font-black">
                <button
                  onClick={() => { setAuthMode('login'); setAuthError(null); }}
                  className={`flex-1 py-2.5 transition rounded-t-xl cursor-pointer ${
                    authMode === 'login' 
                      ? 'border-b-2 border-blue-500 text-blue-400 bg-white/5' 
                      : 'text-slate-500 hover:text-slate-350'
                  }`}
                >
                  Naka-rehistro (Login)
                </button>
                <button
                  onClick={() => { setAuthMode('register'); setAuthError(null); }}
                  className={`flex-1 py-2.5 transition rounded-t-xl cursor-pointer ${
                    authMode === 'register' 
                      ? 'border-b-2 border-blue-500 text-blue-400 bg-white/5' 
                      : 'text-slate-500 hover:text-slate-350'
                  }`}
                >
                  Gawa ng Account (Register)
                </button>
              </div>

              {/* AUTH FORM */}
              <form onSubmit={handleAuthSubmit} className="space-y-3.5 text-xs text-slate-300">
                
                {/* Name - Register only */}
                {authMode === 'register' && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-400 flex items-center gap-1.5">
                      <User className="w-4 h-4" />
                      <span>Buong Pangalan (Profile Name-Admin Visibility)</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Hal. Juan Dela Cruz"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 hover:border-slate-700 p-3 rounded-xl outline-none font-bold text-white transition placeholder:font-normal placeholder:text-slate-600"
                    />
                  </div>
                )}

                {/* Email */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-400 flex items-center gap-1.5">
                    <Mail className="w-4 h-4" />
                    <span>Email Address</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="Hal. juan.delacruz@gmail.com"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 hover:border-slate-700 p-3 rounded-xl outline-none font-bold text-white transition placeholder:font-normal placeholder:text-slate-600"
                  />
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-400 flex items-center gap-1.5">
                    <Lock className="w-4 h-4" />
                    <span>Password</span>
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="Wag kalimutan"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 hover:border-slate-700 p-3 rounded-xl outline-none font-bold text-white transition placeholder:font-normal placeholder:text-slate-600"
                  />
                </div>

                {/* Optional Referral Code - Register only */}
                {authMode === 'register' && (
                  <div className="space-y-1.5 animate-fadeIn">
                    <label className="font-bold text-slate-400 flex items-center gap-1.5">
                      <UserPlus className="w-4 h-4 text-emerald-400" />
                      <span>Referral Code (Opsyonal - pwedeng maiwan na blangko)</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Hal. REF-123456"
                      value={referralInput}
                      onChange={(e) => setReferralInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 hover:border-slate-700 p-3 rounded-xl outline-none font-bold text-white transition placeholder:font-normal placeholder:text-slate-600 truncate uppercase"
                    />
                  </div>
                )}

                {/* Feedbacks */}
                {authError && (
                  <div className="p-3 bg-red-950/85 border border-red-900 rounded-xl flex items-start gap-2 text-[11px] text-red-300 leading-normal">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                    <span className="font-bold">{authError}</span>
                  </div>
                )}

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition py-3 rounded-xl text-white font-black text-xs uppercase tracking-wider cursor-pointer shadow-md flex items-center justify-center gap-2"
                >
                  {authLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : authMode === 'login' ? (
                    'I-verify at Mag-login'
                  ) : (
                    'Gumawa ng Account at Simulan'
                  )}
                </button>

              </form>

            </div>

            <p className="text-center text-[10px] text-slate-600 leading-normal max-w-sm mx-auto">
              {language === 'tl'
                ? "Sa pamamagitan ng pag-sign in, sumasang-ayon ka sa interactive simulator guidelines."
                : "By signing in, you agree to the interactive simulator guidelines."}
            </p>

          </div>
        </div>
      ) : (
        /* 📱 GATEWAY 2: AUTHENTICATED SYSTEM DASHBOARD */
        <>
          {/* HEADER BAR */}
          <header id="dashboard-header" className="bg-slate-900 border-b border-slate-800 text-white py-4 shadow-md sticky top-0 z-40">
            <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              
              {/* BRAND / IDENTITY */}
              <div className="flex items-center gap-3">
                <span className="p-2.5 bg-blue-600 rounded-2xl shadow-md flex items-center justify-center animate-pulse">
                  <Coins className="w-6 h-6 text-yellow-300" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="font-black text-lg tracking-tight">Earning Dashboard</h1>
                    {user.isAdmin && (
                      <span className="bg-red-500 text-white text-[9px] font-black tracking-widest uppercase px-2 py-0.5 rounded flex items-center gap-1">
                        <Shield className="w-3 h-3 text-yellow-250 animate-bounce" />
                        <span>OWNER ADMIN</span>
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 font-semibold">Mag-open ng website homepage upang makatipon ng totoong pera.</p>
                </div>
              </div>

              {/* USER PROFILE CARD AND METRICS */}
              <div className="flex items-center gap-3">
                {/* 🌍 LANGUAGE SELECT SWITCH */}
                <div className="flex items-center gap-1 bg-slate-950/65 border border-slate-800 p-1.5 rounded-2xl shadow-inner shrink-0">
                  <button
                    onClick={() => setLanguage('en')}
                    className={`px-3 py-1.5 text-[10px] font-black uppercase rounded-xl transition-all shrink-0 cursor-pointer flex items-center gap-1 ${
                      language === 'en'
                        ? 'bg-slate-700 text-white shadow font-black scale-105'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <span>🇺🇸</span>
                    <span className="hidden xs:inline">EN</span>
                  </button>
                  <button
                    onClick={() => setLanguage('tl')}
                    className={`px-3 py-1.5 text-[10px] font-black uppercase rounded-xl transition-all shrink-0 cursor-pointer flex items-center gap-1 ${
                      language === 'tl'
                        ? 'bg-indigo-600 text-white shadow font-black scale-105'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <span>🇵🇭</span>
                    <span className="hidden xs:inline">TL</span>
                  </button>
                </div>

                <div className="bg-slate-850 hover:bg-slate-800 border border-slate-800 p-2.5 rounded-2xl flex items-center gap-2.5 transition">
                  <span className="text-2xl bg-slate-900 leading-none p-1 rounded-full shrink-0 select-none shadow-inner">{user.avatar}</span>
                  <div className="min-w-0 pr-1">
                    <h5 className="font-black text-xs leading-none text-white truncate max-w-[130px]" title={user.name}>
                      Mabuhay, {user.name}!
                    </h5>
                    <p className="text-[9px] text-slate-400 mt-1 font-semibold truncate max-w-[130px]" title={user.email}>
                      {user.email}
                    </p>
                    
                    {/* Active Access Badge */}
                    {(() => {
                      const acc = getAccessDetails();
                      const AccIcon = acc.icon;
                      return (
                        <div className={`flex items-center gap-1 text-[8px] font-black px-1.5 py-0.5 rounded-md mt-1.5 leading-none select-none max-w-[130px] truncate ${acc.color}`}>
                          <AccIcon className="w-2 h-2 shrink-0 animate-pulse" />
                          <span>{acc.label}</span>
                        </div>
                      );
                    })()}

                    {!user.isAdmin && (
                      <button
                        onClick={handleSimulateTrialExpiration}
                        className="text-[8px] bg-red-650 hover:bg-red-600 hover:scale-105 active:scale-95 text-white font-black py-0.5 px-1.5 rounded-sm mt-1 transition leading-none select-none cursor-pointer"
                        title="Isimula ang 1-Day Trial Expiration para sa pagsusulit!"
                      >
                        ⚡ Sim Expire
                      </button>
                    )}
                  </div>
                  
                  {/* LOGOUT */}
                  <button 
                    onClick={handleLogout}
                    title="Log-out safe"
                    id="user-logout-btn"
                    className="p-1.5 hover:bg-slate-700/60 transition rounded-xl text-slate-400 hover:text-red-400 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>
          </header>

          {/* GIANT COLOR HERO BANNER PANEL */}
          <div id="hero-marketing-bar" className="bg-slate-900 border-b border-slate-800 py-8 text-white relative overflow-hidden shrink-0">
            
            {/* Ambient colorful vector orbs */}
            <div className="absolute top-0 right-0 h-44 w-44 rounded-full bg-indigo-500/10 blur-3xl" />
            
            <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
              
              {/* DETAILS LEFT */}
              <div className="space-y-2 text-center md:text-left">
                <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase px-2.5 py-1 rounded-full flex items-center gap-1 w-max mx-auto md:mx-0">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>₱1.00 - ₱5.00 PER SIMULATED HOME VIEW</span>
                </span>
                <h2 className="text-2xl md:text-3xl font-black tracking-tight leading-tight max-w-xl">
                  Kumita ng GCash sa Simpleng Pagbukas ng Homepage ng mga Website
                </h2>
                <p className="text-slate-400 text-xs max-w-lg font-semibold">
                  Suriin ang listahan sa ibaba, i-click ang homepage, manatili ng ilang segundo habang natatapos ang automatic browser timer, at pitasin ang iyong gantimplang balanse!
                </p>
              </div>

              {/* WALLET AND REWARDS CENTER STATUS */}
              <div className="flex items-center gap-4 self-center md:self-auto flex-wrap justify-center">
                
                {/* CURRENT BALANCE */}
                <div className="bg-white/10 hover:bg-white/15 border border-white/15 rounded-2xl p-4 min-w-[170px] backdrop-blur-sm transition">
                  <div className="flex items-center justify-between gap-3 text-blue-200 text-[10px] font-bold uppercase tracking-wider">
                    <span>{language === 'tl' ? 'Kasalukuyang Balance' : 'Current Balance'}</span>
                    <Coins className="w-4 h-4 text-yellow-300 animate-spin-slow" />
                  </div>
                  <div className="text-2xl md:text-3xl font-black text-white mt-1 tracking-tight">
                    <span className="text-yellow-300 mr-0.5">₱</span>
                    {stats.balance.toFixed(2)}
                  </div>
                  <p className="text-[10px] text-emerald-300 mt-1 font-semibold flex items-center gap-1">
                    <span>● {language === 'tl' ? 'Ligtas at Pwedeng i-GCash' : 'Secure & GCash Ready'}</span>
                  </p>
                </div>

                {/* ACCESS STATUS CARD */}
                {(() => {
                  const acc = getAccessDetails();
                  const AccIcon = acc.icon;
                  return (
                    <div className="bg-slate-800/40 hover:bg-slate-800/60 border border-slate-700/50 rounded-2xl p-4 min-w-[190px] backdrop-blur-sm transition flex flex-col justify-between">
                      <div className="flex items-center justify-between gap-3 text-slate-300 text-[10px] font-bold uppercase tracking-wider">
                        <span>{language === 'tl' ? 'Akses at Status' : 'Access & Status'}</span>
                        <AccIcon className="w-4 h-4 text-indigo-400 animate-pulse" />
                      </div>
                      <div className="mt-1 flex items-center gap-1.5">
                        <span className={`text-xs font-black px-2 py-0.5 rounded-lg ${acc.color}`}>
                          {acc.label}
                        </span>
                      </div>
                      <p className="text-[9px] text-slate-400 mt-2 font-bold flex items-center gap-1 leading-tight">
                        <span>{acc.expiresText}</span>
                      </p>
                    </div>
                  );
                })()}

                {/* DAILY CHECK IN ACTION */}
                <button
                  id="daily-bonus-checking-btn"
                  onClick={handleDailyCheckIn}
                  className="bg-gradient-to-b from-yellow-300 to-amber-500 hover:from-yellow-200 hover:to-amber-450 text-slate-950 font-black px-5 py-3 rounded-2xl h-full shadow-md text-sm transition hover:scale-[1.02] active:scale-[0.98] cursor-pointer flex flex-col items-center justify-center gap-1 shrink-0"
                >
                  <Sparkles className="w-5 h-5 text-yellow-950 animate-pulse" />
                  <span>₱5.00 Araw Bonus</span>
                </button>

              </div>

            </div>

          </div>

          {/* 🧭 NAVIGATION TABS CONTROL BAR */}
          <div id="dashboard-navigation-tabs" className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 flex items-center justify-between gap-4">
              
              <div className={`w-full grid py-2.5 gap-1 shrink-0 ${user.isAdmin ? 'grid-cols-4' : 'grid-cols-3'} md:flex md:w-auto md:py-3 md:gap-1`}>
                {[
                  { id: 'earn', textMobile: 'Mag-ipon ng Pera', textDesktop: ' (Website Lists)', icon: Globe },
                  { id: 'cashout', textMobile: 'GCash Cash-Out', textDesktop: ' (Withdraw)', icon: Wallet },
                  { id: 'guide', textMobile: 'Gabay sa Paggamit', textDesktop: ' (FAQs)', icon: HelpCircle },
                  // Dynamic Admin tab if the session yields an admin role
                  ...(user.isAdmin ? [{ id: 'admin', textMobile: 'Admin Control', textDesktop: ' Panel', icon: Shield }] : [])
                ].map((tab) => {
                  const IconComp = tab.icon;
                  const isSelected = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      id={`nav-tab-${tab.id}`}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`px-1 py-1.5 sm:px-2 md:px-4.5 md:py-2.5 rounded-xl font-extrabold text-[10px] sm:text-xs md:text-sm transition cursor-pointer flex flex-col md:flex-row items-center justify-center text-center md:text-left gap-1 md:gap-2 leading-tight ${
                        isSelected
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <IconComp className="w-4 h-4 md:w-4.5 md:h-4.5 shrink-0" />
                      <span className="flex flex-col md:flex-row md:items-center gap-0.5 md:gap-1">
                        <span>{tab.textMobile}</span>
                        {tab.textDesktop && (
                          <span className="hidden md:inline text-[10px] md:text-[11px] font-bold opacity-80">
                            {tab.textDesktop}
                          </span>
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="hidden sm:flex items-center gap-1.5 font-mono text-[11px] text-slate-500 font-bold border-l border-slate-200 pl-4 py-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Server Synchronized: Real-Time</span>
              </div>

            </div>
          </div>

          {/* 🖥️ MAIN BODY WORKSPACE */}
          <div id="main-content-layout" className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 md:py-8">
            {isSubscriptionExpired() ? (
              <div className="max-w-2xl mx-auto space-y-6 animate-fadeIn py-6">
                
                {/* SYSTEM ALERT */}
                <div className="bg-rose-50 border border-rose-200 rounded-3xl p-6 shadow-md text-center space-y-4">
                  <div className="h-14 w-14 bg-rose-100 rounded-full flex items-center justify-center mx-auto text-rose-600 animate-bounce">
                    <AlertCircle className="w-8 h-8" />
                  </div>
                  <div className="space-y-1.5">
                    <h2 className="text-xl font-black text-rose-950">⚠️ Tapos na ang Iyong Akses</h2>
                    <p className="text-xs text-rose-800 font-bold max-w-md mx-auto">
                      Ang system access para sa iyong account ay kasalukuyang natapos na dahil ang iyong 1-Day Trial o Subscription ay Expired na.
                    </p>
                  </div>
                </div>

                {/* IF THE REQUEST IS PENDING */}
                {user.subscription?.status === 'pending' ? (
                  <div className="bg-white border-2 border-amber-400 rounded-3xl p-6 shadow-lg space-y-5">
                    <div className="flex items-start gap-4">
                      <div className="bg-amber-100 p-3 rounded-2xl shrink-0 text-amber-600 animate-pulse">
                        <Clock className="w-6 h-6" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="font-extrabold text-slate-900 text-sm">📨 Naghihintay ng Pag-approve ng Admin...</h3>
                        <p className="text-xs text-slate-550 font-bold leading-relaxed">
                          Hiniling mo ang <span className="text-indigo-600 font-black">{user.subscription.requestedPlanName}</span>. Mangyaring magdeposito ng halagang <span className="text-emerald-600 font-black">₱{user.subscription.requestedAmount}</span> sa GCash ni Admin:
                        </p>
                        <div className="bg-slate-50 border border-slate-150 p-3 rounded-2xl mt-2 select-all font-mono font-black text-center text-indigo-700 text-sm tracking-wide">
                          GCASH NO: 0917-000-0000
                        </div>
                      </div>
                    </div>

                    <div className="bg-amber-50/70 border border-amber-150 rounded-2xl p-4 text-xs font-bold text-amber-900 space-y-2 leading-relaxed">
                      <p>💡 **Para sa mabilis na pagsuri (Review & Testing):**</p>
                      <ul className="list-disc pl-4 space-y-1">
                        <li>I-click ang **Mag-logout** sa itaas at mag-login gamit ang Admin account upang aprubahan:</li>
                        <li>Email: <span className="font-mono bg-white px-1 py-0.2 rounded border select-all font-bold text-slate-800">admin@example.com</span></li>
                        <li>Password: <span className="font-mono bg-white px-1 py-0.2 rounded border select-all font-bold text-slate-800">AdminSecurePassword123</span></li>
                        <li>Piliin ang **Subscription Requests** tab sa Admin panel upang i-approve ang iyong account!</li>
                      </ul>
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button
                        onClick={() => fetchUserProfile(token)}
                        className="flex-1 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 transition py-3 rounded-2xl text-slate-950 font-black text-xs cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                      >
                        <RefreshCw className="w-4 h-4 animate-spin-slow" />
                        <span>I-refresh ang Status ng Aking Account</span>
                      </button>
                      <button
                        onClick={handleLogout}
                        className="bg-slate-100 hover:bg-slate-200 transition px-5 py-3 rounded-2xl text-slate-650 font-black text-xs cursor-pointer"
                      >
                        Mag-logout
                      </button>
                    </div>
                  </div>
                ) : (
                  /* SELECTING A SUBSCRIPTION PLAN */
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-lg space-y-6">
                    <div className="text-center space-y-1">
                      <span className="bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] uppercase font-black px-2.5 py-0.5 rounded-full select-none">
                        Mabilisang Pagpipilian (Subscription Plans)
                      </span>
                      <h3 className="font-extrabold text-slate-900 text-sm">Pumili ng Subscription Plan Upang Mag-patuloy</h3>
                      <p className="text-xs text-slate-450 font-semibold max-w-sm mx-auto mt-1">
                        Kapag napili ang nais na plan, awtomatikong ipadadala ang iyong hiling sa admin queue para sa mabilisang validation.
                      </p>
                    </div>

                    {/* PLANS GRID */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {[
                        { id: '1month', name: '1 Month Access', price: 200, desc: '₱200 para sa 30 araw na tuloy-tuloy na earn at cashouts.' },
                        { id: '2months', name: '2 Months Access', price: 500, desc: '₱500 para sa 60 araw na pinalawak na access.' },
                        { id: '3months', name: '3 Months Access', price: 1000, desc: '₱1000 para sa 90 araw na tanyag na VIP access.' },
                        { id: '4months', name: '4 Months Access', price: 2000, desc: '₱2000 para sa 120 araw ng walang katapusang earning portal.' }
                      ].map((plan) => (
                        <div 
                          key={plan.id}
                          className="border border-slate-200 rounded-2xl p-4 hover:border-blue-450 hover:shadow-md transition duration-300 flex flex-col justify-between space-y-4"
                        >
                          <div className="space-y-1">
                            <h4 className="font-extrabold text-slate-900 text-xs">{plan.name}</h4>
                            <div className="text-xl font-bold font-mono text-indigo-650">₱{plan.price}</div>
                            <p className="text-[10px] text-slate-450 leading-relaxed font-semibold">{plan.desc}</p>
                          </div>
                          
                          <button
                            onClick={() => handleSubscriptionRequest(plan.id)}
                            disabled={submittingSubscription}
                            className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 transition py-2 text-white font-black text-xs rounded-xl cursor-pointer shadow-sm text-center"
                          >
                            Bilhin ang Plan na ito
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-slate-100 pt-5 flex items-center justify-between text-xs font-semibold text-slate-500">
                      <span>Hindi pa handang magbayad?</span>
                      <button
                        onClick={handleLogout}
                        className="text-indigo-650 hover:underline font-black cursor-pointer"
                      >
                        I-logout ang aking Account
                      </button>
                    </div>

                  </div>
                )}

              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
              
              {/* TAB SHEETS ZONE (LHS - 3 COLUMNS) */}
              <div className="lg:col-span-3 space-y-6">
                
                {/* TAB 1: EARN CONTENT (VISITOR AD BLOCK) */}
                {activeTab === 'earn' && (
                  <div className="space-y-6 animate-fadeIn">
                    
                    {/* Intro Title */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                      <div>
                        <h2 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                          <Compass className="w-5 h-5 text-blue-600" />
                          <span>Mga Pinagtitiwalaang Web Campaigns ngayong araw</span>
                        </h2>
                        <p className="text-xs text-slate-500 mt-1">Mag-click at manatili sa target homepage para makuha ang automated GCash bonus.</p>
                      </div>
                      <div className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200/50 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        <span>Naka-ipon ngayon: {stats.completedTasksCount} Website Views</span>
                      </div>
                    </div>

                    {/* Filter and Category toggles */}
                    <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs font-semibold">
                      
                      <div className="flex items-center gap-2">
                        <ListFilter className="w-4 h-4 text-slate-500" />
                        <span className="text-slate-500 mr-1.5">Suriin ang Campaigns:</span>
                        {[
                          { id: 'all', label: 'Lahat ng Webs' },
                          { id: 'high', label: 'Mataas ang Kita (≥ ₱1.00)' },
                          { id: 'available', label: 'Hindi pa Nabibisita' }
                        ].map(f => (
                          <button
                            key={f.id}
                            id={`filter-btn-${f.id}`}
                            onClick={() => setCampaignFilter(f.id as any)}
                            className={`px-3 py-1.5 rounded-xl border cursor-pointer transition ${
                              campaignFilter === f.id 
                                ? 'bg-slate-950 border-slate-950 text-white' 
                                : 'bg-slate-50 border-slate-200 text-slate-650 hover:bg-slate-100'
                            }`}
                          >
                            {f.label}
                          </button>
                        ))}
                      </div>

                      <span className="text-[10px] text-slate-400 font-extrabold uppercase">
                        Kabuuang nahanap: {filteredCampaigns.length} available
                      </span>
                    </div>

                    {/* WEBSITE GRID CARDS LIST */}
                    <div id="website-campaigns-grid" className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {filteredCampaigns.map((camp) => (
                        <div 
                          key={camp.id}
                          id={`camp-card-${camp.id}`}
                          className={`bg-white border rounded-2xl p-5 hover:shadow-md transition-all flex flex-col justify-between gap-5 relative overflow-hidden ${
                            camp.completed 
                              ? 'border-emerald-250 bg-emerald-50/10' 
                              : 'border-slate-200'
                          }`}
                        >
                          {/* Top row label and rewards badge */}
                          <div className="flex justify-between items-start gap-3">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="bg-slate-100 text-slate-600 font-bold text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                                {camp.category}
                              </span>
                              {user && user.isAdmin && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteCampaign(camp.id, camp.title);
                                  }}
                                  title="Tanggalin/Burahin ang Campaign"
                                  className="text-rose-500 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200/55 p-1 rounded-lg transition duration-200 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                            
                            <span className="bg-emerald-50 border border-emerald-100 text-[12px] font-black text-emerald-700 px-2.5 py-1 rounded-xl">
                              ₱{camp.reward.toFixed(2)}
                            </span>
                          </div>

                          {/* Middle row main title */}
                          <div className="space-y-1.5">
                            <h4 className="font-extrabold text-slate-900 leading-snug line-clamp-2" title={camp.title}>
                              {camp.title}
                            </h4>
                            <p className="text-[10px] text-slate-400 truncate font-mono">{camp.url}</p>
                            {camp.description && (
                              <p className="text-[11px] text-slate-500 font-semibold leading-relaxed mt-1 line-clamp-2" title={camp.description}>
                                {camp.description}
                              </p>
                            )}
                          </div>

                          {/* Bottom meta rules & Action triggers */}
                          <div className="flex items-center justify-between border-t border-slate-100 pt-3.5 mt-1">
                            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-bold">
                              <Clock className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                              <span>{camp.timer} segundo</span>
                            </div>

                            {camp.completed ? (
                              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-3 py-1.5 rounded-xl flex items-center gap-1 animate-fadeIn">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Tagumpay na nakuha!</span>
                              </span>
                            ) : (
                              <button
                                onClick={() => handleOpenCampaign(camp)}
                                className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-black px-4 py-2 rounded-xl transition shadow shadow-blue-100 flex items-center gap-1 cursor-pointer hover:scale-[1.03]"
                              >
                                <Eye className="w-3.5 h-3.5 shrink-0" />
                                <span>Buksan Homepage</span>
                              </button>
                            )}
                          </div>
                        </div>
                      ))}

                      {filteredCampaigns.length === 0 && (
                        <div className="col-span-full bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-2">
                          <Compass className="w-10 h-10 stroke-1 mx-auto text-slate-350" />
                          <h4 className="font-extrabold text-slate-800">Walang makitang website campaign.</h4>
                          <p className="text-xs text-slate-500 max-w-sm mx-auto font-semibold">
                            Subukang palitan ang list filter o lumapit sa Administrator para sa mga bagong campaign!
                          </p>
                        </div>
                      )}
                    </div>

                    {/* INTERACTIVE FORM: CREATE CUSTOM WEBSITE AD CAMPAIGN WITH EARNING RULES */}
                    {user && user.isAdmin && (
                      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
                        
                        <div className="border-b border-slate-100 pb-3">
                          <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                            <PlusCircle className="w-5 h-5 text-indigo-600" />
                            <span>Mag-add ng Bagong Campaign (Admin Only)</span>
                          </h3>
                          <p className="text-[11px] text-slate-550 mt-0.5">Ipasok ang link, reward, at tagal ng pagbisita upang gawing available sa mga users.</p>
                        </div>

                        <form onSubmit={handleCreateCustomCampaign} className="grid grid-cols-1 md:grid-cols-6 gap-4 text-xs font-semibold">
                          
                          {/* Title input */}
                          <div className="space-y-1 md:col-span-2">
                            <label className="text-slate-500 font-bold block">Pangalan ng Website / Title *</label>
                            <input 
                              type="text" 
                              required
                              placeholder="Hal. My Personal Blog" 
                              value={customTitle}
                              onChange={(e) => setCustomTitle(e.target.value)}
                              className="w-full bg-slate-50 hover:bg-slate-100 focus:bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs outline-hidden font-semibold transition"
                            />
                          </div>

                          {/* URL input */}
                          <div className="space-y-1 md:col-span-2">
                            <label className="text-slate-550 font-bold block">Website Homepage URL *</label>
                            <input 
                              type="text" 
                              required
                              placeholder="Hal. myhomepage.com o blog.org" 
                              value={customUrl}
                              onChange={(e) => setCustomUrl(e.target.value)}
                              className="w-full bg-slate-50 hover:bg-slate-100 focus:bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs outline-hidden font-semibold transition"
                            />
                          </div>

                          {/* Reward amount */}
                          <div className="space-y-1 md:col-span-1">
                            <label className="text-slate-550 font-bold block">Reward (₱) *</label>
                            <input 
                              type="number" 
                              step="0.01"
                              min="0.01"
                              required
                              placeholder="Hal. 2.50" 
                              value={customReward}
                              onChange={(e) => setCustomReward(e.target.value)}
                              className="w-full bg-slate-50 hover:bg-slate-100 focus:bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs outline-hidden font-semibold transition"
                            />
                          </div>

                          {/* Timer */}
                          <div className="space-y-1 md:col-span-1">
                            <label className="text-slate-550 font-bold block">Timer (segundo) *</label>
                            <input 
                              type="number" 
                              min="5"
                              required
                              placeholder="Hal. 15" 
                              value={customTimer}
                              onChange={(e) => setCustomTimer(e.target.value)}
                              className="w-full bg-slate-50 hover:bg-slate-100 focus:bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs outline-hidden font-semibold transition"
                            />
                          </div>

                          {/* Description input */}
                          <div className="space-y-1 md:col-span-6">
                            <label className="text-slate-550 font-bold block">Paglalarawan / Description of Website</label>
                            <textarea 
                              placeholder="Hal. Isang mahusay na blog tungkol sa tech at balita sa bansa." 
                              value={customDescription}
                              onChange={(e) => setCustomDescription(e.target.value)}
                              rows={2}
                              className="w-full bg-slate-50 hover:bg-slate-100 focus:bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs outline-hidden font-semibold transition resize-none"
                            />
                          </div>

                          {/* Action Submit full row */}
                          <div className="md:col-span-6 flex justify-end">
                            <button
                              type="submit"
                              id="create-custom-campaign-btn"
                              className="bg-slate-900 hover:bg-slate-800 text-white font-extrabold px-6 py-2.5 rounded-xl cursor-pointer transition flex items-center justify-center gap-1.5"
                            >
                              <Plus className="w-4 h-4 text-emerald-400" />
                              <span>Mag-add Campaign</span>
                            </button>
                          </div>

                        </form>

                      </div>
                    )}

                  </div>
                )}

                {/* TAB 2: CASHOUT (WITHDRAW GCASH INTEGRATOR) */}
                {activeTab === 'cashout' && (
                  <div className="animate-fadeIn">
                    <GCashCashout 
                      stats={stats} 
                      withdrawals={withdrawals} 
                      onWithdrawSubmit={handleWithdrawalRequest} 
                      language={language}
                    />
                  </div>
                )}

                {/* TAB 3: FAQ GUIDE */}
                {activeTab === 'guide' && (
                  <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6 animate-fadeIn text-xs leading-relaxed text-slate-600">
                    
                    <div className="border-b border-slate-150 pb-4">
                      <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                        <HelpCircle className="w-5 h-5 text-indigo-600" />
                        <span>Gabay at FAQs sa Pag-open ng Homepage Simulator</span>
                      </h2>
                      <p className="text-slate-400 font-bold mt-1">Dito nakasaad ang detalyadong mekanismo kung paano gumagana ang aming real-time system.</p>
                    </div>

                    <div className="space-y-4 font-semibold">
                      
                      <div className="space-y-1.5 border-b border-slate-100 pb-3">
                        <h4 className="font-extrabold text-[#0F172A] text-sm">💡 1. Paano ako makaka-ipon ng totoong pera sa app na ito?</h4>
                        <p>
                          Ang bawat kumpanya ay nangangailangan ng 'Traffic Value' o pagbisita sa kanilang homepage upang mapataas ang kanilang ranking sa search engines. Binabayaran nila ang simulator upang maikalat ang kanilang Links. Sa pamamagitan ng pagbukas at pananatili sa links nang ilang segundo, nakakatulong ka sa kanilang analytics at binibigyan ka ng gantimpalang pondo.
                        </p>
                      </div>

                      <div className="space-y-1.5 border-b border-slate-100 pb-3">
                        <h4 className="font-extrabold text-[#0F172A] text-sm">💡 2. Pwede ko ba talagang i-withdraw ang naipon ko sa pamamagitan ng GCash?</h4>
                        <p>
                          Oo, handog ng interface ang interactive simulated GCash payout workflow! Kapag umabot sa minimum limit na ₱100.00 ang inyong balance, magpunta sa "GCash Cash-Out" tab, ilagay ang iyong GCash details at sumite. Kapag inaprubahan ito ng administrative system sa server, kaagad itong sasalamin sa iyong logs, at sasagutin ng simulated network SMS confirmation!
                        </p>
                      </div>

                      <div className="space-y-1.5 border-b border-slate-100 pb-3">
                        <h4 className="font-extrabold text-[#0F172A] text-sm">
                          {language === 'tl' ? "💡 3. Paano pinoproseso ang administrative dashboard?" : "💡 3. How is the administrative dashboard processed?"}
                        </h4>
                        <p>
                          {language === 'tl' 
                            ? "Ang bawat rehistradong transaksyon ay ipinapadala sa aming administrative system. Ang mga awtorisadong system administrators lamang ang may ganap na kapangyarihan upang pumasok at mag-suri ng registered users, tignan ang kanilang wallet balance, at mag-approve o mag-decline ng withdrawals nang manu-mano sa server."
                            : "Every registered transaction is sent to our administrative system. Only authorized system administrators have the permission to enter and review registered users, check wallet balances, and manually approve or decline withdrawals securely on the server."}
                        </p>
                      </div>

                      <div className="space-y-1.5 pb-2">
                        <h4 className="font-extrabold text-[#0F172A] text-sm">💡 4. Bakit kailangang mag-antay ng "Admin Approval" sa withdrawals?</h4>
                        <p>
                          Ito ay para mapigilan ang mga mapagsamantalang gumagamit ng auto-clicker scripts o bots. Ang administrative approval system ay ang opisyal na tagasubaybay ng bawat activity logs bago tuluyang maproseso ang transaksyon papasok sa mock GCash core network.
                        </p>
                      </div>

                    </div>

                  </div>
                )}

                {/* TAB 4: ADVANCED SECURE ADMIN WORKSPACE */}
                {activeTab === 'admin' && user.isAdmin && (
                  <div className="animate-fadeIn">
                    <AdminPanel 
                      token={token} 
                      triggerNotification={triggerNotification} 
                    />
                  </div>
                )}

              </div>

              {/* SIDEBAR ZONE (RHS - 1 COLUMN) */}
              <div className="space-y-6">
                
                {/* REFERRAL INVITE PANEL IN SIDEBAR */}
                <ReferralPanel
                  referralCode={user.referralCode}
                  referredFriends={referredFriends}
                  token={token}
                  onRefreshProfile={() => fetchUserProfile(token)}
                  triggerNotification={triggerNotification}
                  language={language}
                />

                {/* CORE USER STATUS MOCK WIDGET */}
                <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                    <TrendingUp className="w-4 h-4 text-emerald-600 animate-pulse" />
                    <h4 className="font-extrabold text-slate-900 text-xs tracking-wider uppercase">Live Activity Status</h4>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-center text-xs font-bold leading-tight text-slate-700">
                    <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl">
                      <span className="text-[9px] text-slate-400 block font-black">Lifetime Profit</span>
                      <span className="text-emerald-600 font-extrabold text-sm font-mono mt-1 block">
                        ₱{stats.lifetimeEarnings.toFixed(2)}
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl">
                      <span className="text-[9px] text-slate-400 block font-black">Referred list</span>
                      <span className="text-red-600 font-extrabold text-sm block mt-1">
                        {referredFriends.length} invitees
                      </span>
                    </div>
                  </div>

                  {/* MINI INTERNAL AUDIT LIST */}
                  <div className="space-y-1.5 pt-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-mono text-slate-400 font-bold">Your Recent Activity Logs</span>
                    </div>

                    <div className="space-y-2 overflow-y-auto max-h-[220px] pr-1">
                      {activityLogs.map((log) => (
                        <div key={log.id} className="p-2 bg-slate-50 rounded-xl border border-slate-100 text-[10px] space-y-1">
                          <div className="flex items-center justify-between gap-1.5">
                            <span className={`text-[8px] font-black px-1.5 py-0.2 rounded uppercase ${
                              log.type === 'bonus' 
                                ? 'bg-amber-100 text-amber-800'
                                : log.type === 'reward'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-indigo-100 text-indigo-800'
                            }`}>
                              {log.type}
                            </span>
                            <span className="text-[8px] text-slate-400 font-mono">
                              {log.timestamp.includes(',') ? log.timestamp.split(',')[1].trim() : log.timestamp}
                            </span>
                          </div>

                          <h5 className="font-extrabold text-slate-900 leading-tight">{log.title}</h5>
                          <p className="text-slate-500 text-[9px] leading-tight leading-normal">{log.details}</p>
                          
                          <div className="text-right text-[10px] font-black font-mono mt-0.5">
                            {log.type === 'withdraw' ? (
                              <span className="text-red-600">-₱{log.amount.toFixed(2)}</span>
                            ) : (
                              <span className="text-emerald-600">+₱{log.amount.toFixed(2)}</span>
                            )}
                          </div>
                        </div>
                      ))}
                      {activityLogs.length === 0 && (
                        <p className="text-center py-5 italic text-slate-400 text-[10px]">Wala pang naitalang kasanayan.</p>
                      )}
                    </div>

                  </div>

                  {/* Simulated SMS Alert Preview screen mock for GCash users */}
                  <div className="bg-slate-950 text-white rounded-2xl p-4 shadow-xl border border-slate-800 font-mono relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-1">
                      <div className="h-2 w-2 rounded-full bg-red-400 animate-pulse"></div>
                    </div>
                    <p className="text-[9px] text-emerald-400 font-bold uppercase tracking-wider mb-1.5 flex items-center gap-1">
                      <span>📱 Simulated GCash SMS Monitor</span>
                    </p>
                    <div className="border border-slate-800 rounded bg-slate-900 p-2 text-[10px] text-slate-300 leading-relaxed max-h-[140px] overflow-y-auto">
                      {withdrawals.some(w => w.status === 'success') ? (
                        <div>
                          <p className="text-slate-400 text-[8px] font-semibold">Just Now • Globe Network</p>
                          <p className="text-white mt-1 text-[10px]">
                            "You have received <strong className="text-emerald-400 font-extrabold">₱{withdrawals.find(w => w.status === 'success')?.amount.toFixed(2)}</strong> of GCash from VisitorRewards on {new Date().toLocaleDateString()}. Ref: {withdrawals.find(w => w.status === 'success')?.referenceNo}."
                          </p>
                        </div>
                      ) : (
                        <p className="text-slate-500 italic text-center py-4">Naghihintay ng matagumpay na simulated withdrawal request...</p>
                      )}
                    </div>
                  </div>

                </div>

              </div>

            </div>
            )}
          </div>

          {/* 🌐 VIRTUAL BROWSER SIMULATOR CORE IFRAME PORTAL MODAL OVERLAY */}
          <AnimatePresence>
            {currentViewingCampaign && (
              <BrowserSimulator
                campaign={currentViewingCampaign}
                onComplete={handleCompleteCampaignView}
                onClose={() => setCurrentViewingCampaign(null)}
                language={language}
              />
            )}
          </AnimatePresence>

          {/* FOOTER */}
          <footer id="dashboard-footer" className="bg-white border-t border-slate-200 mt-12 py-6">
            <div className="max-w-7xl mx-auto px-4 text-center space-y-2 text-xs">
              <p className="font-bold text-slate-500">
                © 2026 Website Visitor and GCash Rewards Simulation.
              </p>
              <p className="text-[10px] text-slate-400 max-w-xl mx-auto leading-relaxed font-semibold">
                Ito ay isang interactive gamified web interface upang i-simulate ang pagbisita sa mga homepages bilang kasanayan at pagsuporta sa modernong React techniques. Walang tunay na bank accounts o GCash integrated APIs ang pwedeng mawalan o maubusan ng totoong pondo.
              </p>
            </div>
          </footer>
        </>
      )}

    </div>
  );
}
